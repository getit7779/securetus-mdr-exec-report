import json
import base64, io
from datetime import datetime
from collections import Counter, defaultdict
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd

OUTDIR = Path('output'); OUTDIR.mkdir(parents=True, exist_ok=True)
DATADIR = Path('data'); DATADIR.mkdir(parents=True, exist_ok=True)
SAMPLE_JSON = DATADIR / 'securetus_alerts_sample.json'

with open(SAMPLE_JSON) as f:
    alerts = json.load(f)

for a in alerts:
    a['_dt'] = datetime.strptime(a['timestamp'], '%Y-%m-%dT%H:%M:%SZ')
alerts.sort(key=lambda x: x['_dt'])

sev_counts = Counter(a['severity'] for a in alerts)
rule_counts = Counter(a['rule']['description'] for a in alerts)
host_counts = Counter(a['agent']['name'] for a in alerts)

by_day = defaultdict(int)
for a in alerts:
    by_day[a['_dt'].strftime('%Y-%m-%d')] += 1
trend_days = sorted(by_day.keys())

mitre_map = {
    'Multiple failed logins detected': 'Credential Access (T1110)',
    'Successful admin login from unusual location': 'Valid Accounts (T1078)',
    'Malicious process name detected': 'Defense Evasion (T1036)',
    'Suspicious outbound connection': 'Command and Control (T1071)',
    'Port scan behavior detected': 'Discovery (T1046)',
    'Critical system file changed': 'Persistence (varies)'
}
mitre_counts = Counter(mitre_map.get(a['rule']['description'], 'N/A') for a in alerts)

summary_rows = [{'Rule Description': d, 'Count': c, 'Mapped MITRE Tactic/Technique': mitre_map.get(d, 'N/A')} for d, c in rule_counts.most_common()]
summary_df = pd.DataFrame(summary_rows)
csv_path = OUTDIR / 'securetus_alerts_summary.csv'
summary_df.to_csv(csv_path, index=False)

def fig_to_b64(fig):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format='png')
    plt.close(fig); buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode('utf-8')

fig1 = plt.figure()
plt.bar(list(sev_counts.keys()), list(sev_counts.values()))
plt.title('Alerts by Severity'); plt.xlabel('Severity'); plt.ylabel('Count')
sev_png_b64 = fig_to_b64(fig1)

fig2 = plt.figure()
x = [datetime.strptime(d, '%Y-%m-%d') for d in trend_days]
y = [by_day[d] for d in trend_days]
plt.plot(x, y, marker='o')
plt.title('Alerts Over Time (Last 7 Days)'); plt.xlabel('Date'); plt.ylabel('Alerts')
trend_png_b64 = fig_to_b64(fig2)

def table_from_counter(counter_obj, title, max_rows=10):
    rows = ''.join(f"<tr><td>{k}</td><td style='text-align:right'>{v}</td></tr>" for k, v in counter_obj.most_common(max_rows))
    return f"<h3>{title}</h3><table><thead><tr><th>Item</th><th>Count</th></tr></thead><tbody>{rows}</tbody></table>"

def table_from_df(df, title, max_rows=12):
    head = '<thead><tr>' + ''.join(f'<th>{c}</th>' for c in df.columns) + '</tr></thead>'
    body_rows = []
    for _, row in df.head(max_rows).iterrows():
        body_rows.append('<tr>' + ''.join(f'<td>{row[c]}</td>' for c in df.columns) + '</tr>')
    body = '<tbody>' + ''.join(body_rows) + '</tbody>'
    return f"<h3>{title}</h3><table>{head}{body}</table>"

generated_ts = datetime.now().strftime('%Y-%m-%d %H:%M')
html = (
    "<!doctype html><html><head><meta charset='utf-8'><title>Securetus Executive Security Report</title>"
    "<style>body{font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:30px;color:#222}"
    "h1,h2,h3{margin-bottom:8px}.muted{color:#666;font-size:.9rem}"
    ".cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;margin:16px 0}"
    ".card{border:1px solid #eee;border-radius:12px;padding:16px;box-shadow:0 2px 6px rgba(0,0,0,.04)}"
    ".kpi{font-size:2rem;font-weight:700}table{border-collapse:collapse;width:100%;margin:12px 0 24px}"
    "th,td{border-bottom:1px solid #eee;padding:8px;text-align:left}"
    ".flex{display:flex;gap:20px;flex-wrap:wrap;align-items:center}"
    ".chart{max-width:520px;width:100%;border:1px solid #eee;border-radius:12px;padding:12px}"
    ".footer{margin-top:40px;font-size:.9rem;color:#666}</style></head><body>"
    f"<h1>Securetus Executive Security Report</h1><div class='muted'>Generated: {generated_ts}</div>"
    "<h2>Overview</h2><div class='cards'>"
    f"<div class='card'><div class='muted'>Total Alerts</div><div class='kpi'>{len(alerts)}</div></div>"
    f"<div class='card'><div class='muted'>Hosts Monitored</div><div class='kpi'>{len(set(a['agent']['name'] for a in alerts))}</div></div>"
    f"<div class='card'><div class='muted'>Top Severity</div><div class='kpi'>{max(sev_counts, key=sev_counts.get).title()}</div></div>"
    f"<div class='card'><div class='muted'>Top Host</div><div class='kpi'>{max(dict(Counter(a['agent']['name'] for a in alerts)), key=lambda x:Counter(a['agent']['name'] for a in alerts)[x])}</div></div></div>"
    "<div class='flex'><div class='chart'><h3>Alerts by Severity</h3>"
    f"<img src='data:image/png;base64,{sev_png_b64}' alt='Alerts by Severity'/></div>"
    "<div class='chart'><h3>Alerts Over Time (Last 7 Days)</h3>"
    f"<img src='data:image/png;base64,{trend_png_b64}' alt='Alerts Over Time'/></div></div>"
    f"{table_from_df(summary_df, 'Top Detections & MITRE Mapping')}"
    f"{table_from_counter(Counter(a['agent']['name'] for a in alerts), 'Top Affected Hosts')}"
    f"{table_from_counter(sev_counts, 'Severity Distribution')}"
    "<div class='footer'><strong>How to Use This Report</strong><br/>"
    "Share with executives, tune detections, and schedule monthly runs.<br/><br/>"
    "<em>Powered by Securetus — Managed Detection & Response.</em></div></body></html>"
)
(OUTDIR / 'securetus_report.html').write_text(html, encoding='utf-8')
print('Report written to output/securetus_report.html')
print('Summary CSV written to output/securetus_alerts_summary.csv')
